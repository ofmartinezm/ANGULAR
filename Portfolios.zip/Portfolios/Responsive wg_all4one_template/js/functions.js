// remap jQuery to $
(function($){})(window.jQuery);


/* trigger when page is ready */
$(document).ready(function (){

	// Background Image
	 $.backstretch("../images/page-bg-img.jpg");

});
