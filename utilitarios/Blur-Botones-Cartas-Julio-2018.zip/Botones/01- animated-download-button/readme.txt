Design Curate
=======================
Item: Animated CSS Download Button
Type: HTML/CSS
Author: Josh Johnson



Notes
=======================
Six awesome image-free buttons coded with pure HTML and CSS. Each button is equipped with three different states: default, hover and active. 

Button design and code tutorial found here:
http://designshack.net/articles/css/downloadbutton/

Unfortunately we don't offer any support for integrating these buttons into your own design. It should be a fairly straight-forward copy and paste job though!


Free Resource Licensing
=======================
All our free resources are licensed under a Creative Commons Attribution license. This license lets you distribute, remix, tweak, and build upon your work, even commercially, as long as you credit Design Curate for the original creation:

http://creativecommons.org/licenses/by/3.0/