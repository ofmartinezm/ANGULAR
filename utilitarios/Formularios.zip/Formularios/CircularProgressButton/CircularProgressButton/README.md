Circular Progress Button with SVG
=========

Implementation of Colin Garvin's [submit button concept](http://dribbble.com/shots/1426764-Submit-Button)

[Article on Codrops](http://tympanus.net/codrops/?p=18828)

[Demo](http://tympanus.net/Tutorials/CircularProgressButton/)

Integrate or build upon it for free in your personal or commercial projects. Don't republish, redistribute or sell "as-is". 

Read more here: [License](http://tympanus.net/codrops/licensing/)


[© Codrops 2014](http://www.codrops.com)